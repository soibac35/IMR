﻿using IRM.Models;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IRM.Controllers
{
    public class HomeController : Controller
    {
        private DBModel _context = new DBModel();
        public ActionResult Index()
        {
            var a = _context.AspNetUsers.Select(x => new Users() { UserName = x.UserName, FullName = x.FullName, Status = x.Status }).ToList();
            ViewBag.ListUser = a;
            ViewBag.GetUser = _context.AspNetUsers.Select(x => new Users() { UserName = x.UserName, FullName = x.FullName, Status = x.Status })
                .Where(x => x.UserName == User.Identity.Name).Take(1).SingleOrDefault();
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [HttpPost]
        public object Check(int? status)
        {
            try
            {
                var a = _context.AspNetUsers.First(x => x.UserName == User.Identity.Name);
                a.Status = status;
                _context.Entry(a).Property(x => x.Status).IsModified = true;
                _context.SaveChanges();
                return Json(new { Title = "Thành công", Error = false });
            }
            catch (Exception ex)
            {
                return Json(new { Title = "Không thành công", Error = true });
            }
        }
        [HttpPost]
        public object Delete()
        {
            try
            {
                var a = _context.AspNetUsers.First(x => x.UserName == User.Identity.Name);
                _context.AspNetUsers.Remove(a);
                _context.SaveChanges();
                AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                return Json(new { Title = "Xóa không thành công", Error = true });
            }
        }
        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }
    }
}